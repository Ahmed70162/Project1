
from flask import Flask, render_template, request, redirect, session
import json

app = Flask(__name__)
app.secret_key = "secret123"

CONFIG_FILE = "../config.json"

def load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)

@app.route("/")
def index():
    config = load_config()
    return render_template("index.html", config=config)

@app.route("/panel", methods=["POST"])
def panel():
    config = load_config()
    config["panel_message"] = request.form.get("message")
    save_config(config)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
