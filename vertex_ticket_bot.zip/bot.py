
import discord
from discord.ext import commands
import json
import os

TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)

TICKET_CATEGORY_NAME = "Tickets"

def get_config():
    if not os.path.exists("config.json"):
        return {}
    with open("config.json", "r") as f:
        return json.load(f)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.command()
async def setup(ctx):
    guild = ctx.guild
    category = discord.utils.get(guild.categories, name=TICKET_CATEGORY_NAME)
    if not category:
        category = await guild.create_category(TICKET_CATEGORY_NAME)

    await ctx.send("Ticket system initialized.")

@bot.command()
async def ticket(ctx):
    guild = ctx.guild
    category = discord.utils.get(guild.categories, name=TICKET_CATEGORY_NAME)

    channel = await guild.create_text_channel(
        name=f"ticket-{ctx.author.name}",
        category=category
    )

    await channel.set_permissions(ctx.guild.default_role, read_messages=False)
    await channel.set_permissions(ctx.author, read_messages=True)

    await channel.send(f"Welcome {ctx.author.mention}, support will be with you shortly.")

    await ctx.send("Ticket created.")
